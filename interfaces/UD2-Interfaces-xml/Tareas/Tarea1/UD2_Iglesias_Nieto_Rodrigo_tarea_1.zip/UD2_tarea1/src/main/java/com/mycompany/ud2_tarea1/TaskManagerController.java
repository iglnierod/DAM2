/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ud2_tarea1;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 *
 * @author ald
 */
public class TaskManagerController {

    @FXML
    private Button addTask;

    @FXML
    private TextField taskDescription;

    @FXML
    private ListView<String> taskList;

    @FXML
    private void quit() throws IOException {
        System.exit(0);
    }

    @FXML
    private void addTask(ActionEvent event) {
        if (!this.taskDescription.getText().isEmpty()) {
            this.taskList.getItems().add(this.taskDescription.getText());
        }
    }

}
