module com.mycompany.ud2_tarea1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;
    requires java.base;

    opens com.mycompany.ud2_tarea1 to javafx.fxml;
    exports com.mycompany.ud2_tarea1;
}
