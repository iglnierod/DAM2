/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package view.booking;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public class BookingInformationDialog extends javax.swing.JDialog {
    
    public BookingInformationDialog(BookingDialog parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bookingHolderLabel = new javax.swing.JLabel();
        roomTypeComboBox = new javax.swing.JComboBox<>();
        bookingHolderTextField = new javax.swing.JTextField();
        roomTypeLabel = new javax.swing.JLabel();
        smokerCheckBox = new javax.swing.JCheckBox();
        wifiCheckBox = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        bookingHolderLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        bookingHolderLabel.setText("Booking Holder:");

        roomTypeComboBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        bookingHolderTextField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        roomTypeLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomTypeLabel.setText("Room Type:");

        smokerCheckBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        smokerCheckBox.setText("Smoker");

        wifiCheckBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        wifiCheckBox.setText("Wi-Fi");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(bookingHolderLabel)
                            .addComponent(roomTypeLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(roomTypeComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bookingHolderTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(wifiCheckBox)
                            .addComponent(smokerCheckBox))))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bookingHolderLabel)
                    .addComponent(bookingHolderTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(roomTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roomTypeLabel))
                .addGap(18, 18, 18)
                .addComponent(smokerCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(wifiCheckBox)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void setBookingHolderTextFieldEnabled(boolean bool) {
        this.bookingHolderTextField.setEnabled(bool);
    }
    
    public void setRoomTypeComboBoxEnabled(boolean bool) {
        this.roomTypeComboBox.setEnabled(bool);
    }
    
    public void setSmokerCheckBoxEnabled(boolean bool) {
        this.smokerCheckBox.setEnabled(bool);
    }
    
    public void setWifiCheckBoxEnabled(boolean bool) {
        this.wifiCheckBox.setEnabled(bool);
    }
    
    
    public void setSmokerCheckBoxSelected(boolean selected) {
        this.smokerCheckBox.setSelected(selected);
    }
    
    public void setWifiCheckBoxSelected(boolean selected) {
        this.wifiCheckBox.setSelected(selected);
    }
    
    public void setSelectedItemRoomTypeComboBox(String roomType) {
        this.roomTypeComboBox.addItem(roomType);
    }
    
    public void setBookingHolderTextFieldText(String holder) {
        this.bookingHolderTextField.setText(holder);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bookingHolderLabel;
    private javax.swing.JTextField bookingHolderTextField;
    private javax.swing.JComboBox<String> roomTypeComboBox;
    private javax.swing.JLabel roomTypeLabel;
    private javax.swing.JCheckBox smokerCheckBox;
    private javax.swing.JCheckBox wifiCheckBox;
    // End of variables declaration//GEN-END:variables
}
