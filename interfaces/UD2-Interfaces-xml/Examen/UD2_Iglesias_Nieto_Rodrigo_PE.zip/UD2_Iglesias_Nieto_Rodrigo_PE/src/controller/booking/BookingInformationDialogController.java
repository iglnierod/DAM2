/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.booking;

import model.Booking;
import view.booking.BookingInformationDialog;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public class BookingInformationDialogController {

    private final BookingInformationDialog view;
    private final Booking model;

    public BookingInformationDialogController(BookingInformationDialog view, Booking model) {
        this.view = view;
        this.model = model;
        this.enableFields(false);
        this.loadBooking();
    }
    
    private void enableFields(boolean bool) {
        this.view.setBookingHolderTextFieldEnabled(bool);
        this.view.setRoomTypeComboBoxEnabled(bool);
        this.view.setSmokerCheckBoxEnabled(bool);
        this.view.setWifiCheckBoxEnabled(bool);
    }
    
    private void loadBooking() {
        this.view.setBookingHolderTextFieldText(this.model.getHolder());
        this.view.setSelectedItemRoomTypeComboBox(this.model.getRoomType().toString());
        this.view.setSmokerCheckBoxSelected(this.model.isSmoker());
        this.view.setWifiCheckBoxSelected(this.model.isWifi());
    }
}
