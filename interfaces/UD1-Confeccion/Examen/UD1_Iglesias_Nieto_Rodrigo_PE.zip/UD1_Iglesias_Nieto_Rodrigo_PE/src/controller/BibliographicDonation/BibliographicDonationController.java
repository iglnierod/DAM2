/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.BibliographicDonation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.BibliographicDonation;
import view.BibliographicDonation.BibliographicDonationDialog;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public class BibliographicDonationController {

    private final BibliographicDonationDialog view;
    private final BibliographicDonation model;

    public BibliographicDonationController(BibliographicDonationDialog view, BibliographicDonation model) {
        this.view = view;
        this.model = model;
        this.addAllListeners();
    }

    private void addAllListeners() {
        this.view.setCancelButtonActionListener(setCancelButtonActionListener());
        this.view.setAcceptButtonActionListener(setAcceptButtonActionListener());
    }

    private ActionListener setCancelButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        };
        return al;
    }

    private ActionListener setAcceptButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setName(view.getNameText());
                model.setEmail(view.getEmailText());
                model.setPhoneNumber(view.getPhoneNumberText());
                model.setPhoneType(view.getSelectedTypeOfPhone());
                model.setDate(view.getDateText());
                model.setTypeOfDonative(view.getTypeOfDonativeText());
                model.setNumberOfDonatives(view.getNumberOfDonativesValue());
                model.setSpam(view.getSpamConfirmation());
                
                JOptionPane.showMessageDialog(view, "Donación realizada", "Confirmación",JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Se ha realizado la donación:");
                System.out.println(model);
            }
        };
        return al;
    }
}
