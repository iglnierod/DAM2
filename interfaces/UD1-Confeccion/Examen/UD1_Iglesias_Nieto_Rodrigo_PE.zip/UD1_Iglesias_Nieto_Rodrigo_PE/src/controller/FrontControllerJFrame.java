/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import controller.BibliographicDonation.BibliographicDonationController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.BibliographicDonation;
import view.BibliographicDonation.BibliographicDonationDialog;
import view.MainJFrame;

/**
 *
 * @author dides
 */
public class FrontControllerJFrame {

    private MainJFrame view;
    private BibliographicDonation model;
    
    public FrontControllerJFrame(MainJFrame view, BibliographicDonation model) {
        this.view = view;
        this.model = model;
        this.view.setQuitMenuItemListener(this.setQuitMenuItemActionListener());
        this.view.setManageBibliographicDonationsMenuItem(this.setManageBibliographicDonationsActionListener());
    }

    private ActionListener setQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }

    private ActionListener setManageBibliographicDonationsActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BibliographicDonationDialog bdd = new BibliographicDonationDialog(view, true);
                BibliographicDonationController bdc = new BibliographicDonationController(bdd, model);
                bdd.setVisible(true);
            }
        };
        return al;
    }

}
