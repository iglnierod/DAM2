/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public class BibliographicDonation {

    private String name;
    private String email;
    private String phoneNumber;
    private String phoneType;
    private String date;
    private String typeOfDonative;
    private int numberOfDonatives;
    private boolean spam;

    public BibliographicDonation() {
        super();
    }
    
    public BibliographicDonation(String name, String email, String phoneNumber,
            String phoneType, String date, String materialDonated, int numberOfDonatives, boolean spam) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.phoneType = phoneType;
        this.date = date;
        this.typeOfDonative = materialDonated;
        this.numberOfDonatives = numberOfDonatives;
        this.spam = spam;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTypeOfDonative(String typeOfDonative) {
        this.typeOfDonative = typeOfDonative;
    }

    public void setNumberOfDonatives(int numberOfDonatives) {
        this.numberOfDonatives = numberOfDonatives;
    }

    public void setSpam(boolean spam) {
        this.spam = spam;
    }

    
    
    @Override
    public String toString() {
        return "BibliographicDonation{"
                + "name='" + name + '\''
                + ", email='" + email + '\''
                + ", phoneNumber='" + phoneNumber + '\''
                + ", phoneType='" + phoneType + '\''
                + ", date='" + date + '\''
                + ", typeOfDonative='" + typeOfDonative + '\''
                + ", numberOfDonatives=" + numberOfDonatives
                + ", spam=" + spam
                + '}';
    }
}
