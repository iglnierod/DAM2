/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.salonPalace;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.salonPalace.SalonPalaceDialog;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public class SalonPalaceController {

    private final SalonPalaceDialog view;

    public SalonPalaceController(SalonPalaceDialog view) {
        this.view = view;
        this.view.setSendPetitioButtonListener(setSendPetitionButtonActionListener());
    }

    private ActionListener setSendPetitionButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(view, "Confirmar reserva?", "Confirmar", JOptionPane.OK_CANCEL_OPTION);
                System.out.println("Option selected: " + option);

                switch (option) {
                    case 0: // Confirm
                        System.out.println("Reserva enviada.");
                        JOptionPane.showMessageDialog(view, "Reserva enviada.", "Confirmación reserva", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        view.dispose();
                }
            }
        };
        return al;
    }
}
