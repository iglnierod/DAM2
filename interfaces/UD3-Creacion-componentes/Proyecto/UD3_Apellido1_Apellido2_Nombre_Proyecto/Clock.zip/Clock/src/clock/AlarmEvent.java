package clock;

import java.util.EventObject;

public class AlarmEvent extends EventObject {

    public AlarmEvent(Object source) {
        super(source);
    }

}
