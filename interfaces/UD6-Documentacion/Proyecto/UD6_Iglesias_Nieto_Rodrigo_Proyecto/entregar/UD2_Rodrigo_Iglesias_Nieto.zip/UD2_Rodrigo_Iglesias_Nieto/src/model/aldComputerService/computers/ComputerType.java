/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package model.aldComputerService.computers;

/**
 *
 * @author iglesias_nieto_rodrigo
 */
public enum ComputerType {
   LAPTOP, PERSONAL_COMPUTER, SERVER
}
