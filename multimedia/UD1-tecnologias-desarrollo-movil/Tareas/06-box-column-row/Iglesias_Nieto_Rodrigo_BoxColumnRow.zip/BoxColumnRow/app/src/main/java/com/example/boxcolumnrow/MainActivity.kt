package com.example.boxcolumnrow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.boxcolumnrow.ui.theme.BoxColumnRowTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BoxColumnRowTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background
                ) {
                    MyRowBox(contentAlignment = Alignment.TopStart, Color.Yellow, "Estoy arriba")
                    MyColumnBox("Izquierda", Color.Red, "Derecha", Color.Green)
                    MyRowBox(contentAlignment = Alignment.BottomCenter, Color.Blue, "Estoy arriba")
                }
            }
        }
    }
}

@Composable
fun MyRowBox(contentAlignment: Alignment, color: Color, text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = contentAlignment) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.335f)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(text = text)
        }
    }
}

@Composable
fun MyColumnBox(txtLeft: String, colorLeft: Color, txtRight: String, colorRight: Color) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(0.33f)
                    .background(colorLeft),
                contentAlignment = Alignment.Center
            ) {
                Text(text = txtLeft)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(0.33f)
                    .background(colorRight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = txtRight)
            }
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun MyBoxPreview() {
    BoxColumnRowTheme {
        MyRowBox(contentAlignment = Alignment.TopStart, Color.Yellow, "Estoy arriba")
        MyColumnBox("Izquierda", Color.Red, "Derecha", Color.Green)
        MyRowBox(contentAlignment = Alignment.BottomCenter, Color.Blue, "Estoy arriba")
    }
}