import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Servidor esperando conexiones...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado desde: " + clientSocket.getInetAddress());

                String clientMessage = null;
                try (
                        BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                        PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)
                ) {
                    int connectionCount = 0;

                    while ((clientMessage = reader.readLine()) != null) {
                        if (clientMessage.equals("Exit")) {
                            break;
                        }

                        if (clientSocket.getInetAddress().getHostAddress().equals(clientMessage)) {
                            connectionCount++;
                            writer.println("Respuesta del servidor: " + clientSocket.getInetAddress().getHostAddress());
                            System.out.println("Mensaje recibido del cliente " + connectionCount + ": " + clientMessage);
                        } else {
                            writer.println("Error: IP del cliente no coincide con la IP detectada por el servidor.");
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (clientMessage != null && clientMessage.equals("Exit")) {
                    System.out.println("Servidor desconectado.");
                    break;
                }
            }

            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
