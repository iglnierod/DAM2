import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            try {
                Socket socket = new Socket("localhost", 8080);

                try (
                        PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))
                ) {
                    writer.println(socket.getLocalAddress().getHostAddress());

                    String serverResponse = reader.readLine();
                    System.out.println("Respuesta del servidor: " + serverResponse);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (i == 4) {
                    try (Socket exitSocket = new Socket("localhost", 8080);
                         PrintWriter exitWriter = new PrintWriter(exitSocket.getOutputStream(), true)) {
                        exitWriter.println("Exit");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
