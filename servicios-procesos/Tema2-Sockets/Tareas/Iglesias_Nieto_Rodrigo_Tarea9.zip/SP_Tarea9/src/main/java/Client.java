import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            String characters = "abcdefghij";
            for (int i = 0; i < characters.length(); i++) {

                DatagramSocket clientSocket = new DatagramSocket();

                InetAddress serverAddress = InetAddress.getByName("localhost");
                int serverPort = 8080;

                String clientMessage = String.valueOf(characters.charAt(i));
                byte[] sendData = clientMessage.getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);

                clientSocket.send(sendPacket);
                System.out.println("Mensaje envidao al servidor: " + clientMessage);

                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                clientSocket.receive(receivePacket);

                String serverResponse = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Respuesta del servidor: " + serverResponse);
                clientSocket.close();
            }

        } catch (SocketException e) {
            throw new RuntimeException(e);
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
