package Tarea_12.Client;

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            System.out.println("Connected to server.");

            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter file name: ");
            String fileName = reader.readLine();
            dos.writeUTF(fileName);

            String response = dis.readUTF();
            if (response.equals("EXISTS")) {
                FileOutputStream fos = new FileOutputStream("received_" + fileName);
                BufferedOutputStream bos = new BufferedOutputStream(fos);
                InputStream inFile = socket.getInputStream();

                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inFile.read(buffer)) != -1) {
                    bos.write(buffer, 0, bytesRead);
                }

                bos.close();
                fos.close();
                System.out.println("File received: " + "received_" + fileName);
            } else {
                System.out.println("File does not exist on server.");
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

