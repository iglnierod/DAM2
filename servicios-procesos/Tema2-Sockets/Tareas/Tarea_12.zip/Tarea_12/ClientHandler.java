package Tarea_12;

import java.io.*;
import java.net.*;

class ClientHandler implements Runnable {
    private Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try {
            DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());

            String fileName = dis.readUTF();
            System.out.println("Received file request: " + fileName);

            File file = new File(fileName);
            if (file.exists() && !file.isDirectory()) {
                dos.writeUTF("EXISTS");

                FileInputStream fis = new FileInputStream(file);
                BufferedInputStream bis = new BufferedInputStream(fis);
                DataOutputStream outFile = new DataOutputStream(clientSocket.getOutputStream());

                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = bis.read(buffer)) != -1) {
                    outFile.write(buffer, 0, bytesRead);
                }

                bis.close();
                fis.close();
                outFile.close();
                System.out.println("File sent: " + fileName);
            } else {
                dos.writeUTF("NOT_EXISTS");
                System.out.println("File not found: " + fileName);
            }

            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
