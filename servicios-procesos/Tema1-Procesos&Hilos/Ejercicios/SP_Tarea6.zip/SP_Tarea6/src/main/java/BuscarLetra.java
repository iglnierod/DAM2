public class BuscarLetra implements Runnable {
    private String vocal;
    private String cadena;
    private Contador contador;
    private int contadorLocal;

    public BuscarLetra(String vocal, String cadena, Contador contador) {
        this.vocal = vocal.toUpperCase();
        this.cadena = cadena.toUpperCase();
        this.contador = contador;
        this.contadorLocal = 0;
    }

    @Override
    public void run() {
        for (int i = 0; i < cadena.length(); i++) {
            if (vocal.equals(String.valueOf(cadena.charAt(i)))) {
                this.contadorLocal++;
            }
        }
        this.contador.sumar(contadorLocal);
        System.out.printf("%s: %d\n", this.vocal, this.contadorLocal);
    }
}
