public class Contador {
    private int contador;

    public Contador() {
        contador = 0;
    }

    public int getContador() {
        return this.contador;
    }
    public synchronized void sumar(int n) {
        this.contador+= n;
    }

}
