import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Contador c = new Contador();
        String cadena = leerCadena();
        String[] vocales = new String[]{"A","E","I","O","U"};
        BuscarLetra[] buscarLetras = new BuscarLetra[vocales.length];
        for (int i = 0; i < buscarLetras.length; i++) {
            buscarLetras[i] = new BuscarLetra(vocales[i], cadena, c);
        }

        for(BuscarLetra bl : buscarLetras) {
            Thread hilo = new Thread(bl);
            hilo.start();
        }
        Thread.sleep(2000);
        System.out.println("Contador total de vocales: " + c.getContador());
    }

    private static String leerCadena() {
        try (BufferedReader reader = new BufferedReader(new FileReader("cadena.txt"))) {
            String linea;
            StringBuilder cadena = new StringBuilder();
            while ((linea = reader.readLine()) != null) {
                cadena.append(linea);
            }
            return cadena.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
