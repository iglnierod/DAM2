public class Main {
    public static void main(String[] args) throws InterruptedException {
        Banco banco = new Banco();
        Cliente[] clientes = new Cliente[200];
        for (int i = 0; i < clientes.length; i++) {
            clientes[i] = new Cliente(banco);
        }

        for (Cliente c : clientes) {
            Thread hilo = new Thread(c);
            hilo.start();
        }
        Thread.sleep(2000);
        System.out.println("EL BALANCE DEL BANCO ES: " + banco.balance());
    }
}
