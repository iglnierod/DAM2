public class Banco {
    private int saldo;

    public Banco() {
        this.saldo = 0;
    }

    public synchronized void depositar(int cantidad) {
        this.saldo += cantidad;
    }

    public synchronized void retirar(int cantidad) {
        this.saldo -= cantidad;
    }

    public int balance() {
        return this.saldo;
    }
}
