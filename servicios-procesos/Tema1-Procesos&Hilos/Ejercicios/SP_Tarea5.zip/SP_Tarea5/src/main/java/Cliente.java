import java.util.Random;

public class Cliente implements Runnable {
    private Banco banco;

    public Cliente(Banco banco) {
        this.banco = banco;
    }

    @Override
    public void run() {
        Random r = new Random();

        for (int i = 0; i < r.nextInt(2, 12); i++) {
            int ingreso = r.nextInt(2500);
            this.banco.depositar(ingreso);
//            System.out.println("+ " + ingreso);
        }

        for (int i = 0; i < r.nextInt(2, 8); i++) {
            int retiro = r.nextInt(2500);
            this.banco.retirar(retiro);
//            System.out.println(" - " + retiro);
        }
    }
}
