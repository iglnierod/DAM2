import java.io.File;
import java.io.IOException;

public class Main {
    static final String PROJECT_PATH = new File("").getAbsolutePath();

    public static void main(String[] args) throws IOException, InterruptedException {
        String comando = "Proceso1";
        File ficheroError = new File("error.txt");
        File ficheroResultado = new File("resultado.txt");

        ProcessBuilder pb = new ProcessBuilder("java", "-cp", PROJECT_PATH + "\\out\\production\\SP_Tarea1\\", comando, ficheroResultado.getAbsolutePath());
        pb.redirectError(ficheroError);
        pb.redirectInput(ProcessBuilder.Redirect.INHERIT);
        pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        boolean passwordMatched = false;
        while (!passwordMatched) {
            Process p = pb.start();
            p.waitFor();

            comando = "java -cp " + PROJECT_PATH + "\\out\\production\\SP_Tarea1\\" + " Proceso2 " + ficheroResultado.getAbsolutePath();
            pb = new ProcessBuilder("cmd", "/c", comando);
            pb.redirectError(ficheroError);
            pb.redirectInput(ProcessBuilder.Redirect.INHERIT);
            pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
            p = pb.start();
            int exitCode = p.waitFor();

            if (exitCode == 0) {
                passwordMatched = true;
                System.out.println("Contraseña correcta. Terminando el programa.");
            } else {
                System.out.println("Contraseña incorrecta. Vuelve a intentarlo.");
                main(args);
            }
        }
    }
}
