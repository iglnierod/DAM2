import java.io.*;
public class Proceso2 {
    private static final String PASSWORD = "abc123.";

    public static void main(String[] args) {
        String filePath = args[0];

        if (checkPassword(filePath)) {
            System.exit(0); // Terminar el proceso con éxito
        } else {
            System.exit(1); // Terminar el proceso con un código de error
        }
    }

    public static boolean checkPassword(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String pwd = reader.readLine();
            return pwd.equals(PASSWORD);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
