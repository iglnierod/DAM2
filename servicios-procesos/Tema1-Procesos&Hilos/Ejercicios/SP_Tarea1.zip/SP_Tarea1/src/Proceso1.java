import java.io.*;
import java.util.Scanner;

public class Proceso1 {
    File file;

    public Proceso1(String str, InputStream inputStream, OutputStream outputStream) {
        this.file = new File(str);
        createFile();
        waitForInput(inputStream);
    }

    private void createFile() {
        try {
            file.createNewFile();
        } catch (IOException e) {
            System.out.println("Proceso 1: ERROR: No se ha podido crear el fichero");
        }
    }

    private void waitForInput(InputStream inputStream) {
        Scanner sc = new Scanner(inputStream);
        System.out.println("Proceso 1: Escribe la clave:");
        try (FileWriter writer = new FileWriter(this.file)) {
            String str = sc.nextLine();
            writer.write(str);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        new Proceso1(args[0], System.in, System.out);
    }
}
