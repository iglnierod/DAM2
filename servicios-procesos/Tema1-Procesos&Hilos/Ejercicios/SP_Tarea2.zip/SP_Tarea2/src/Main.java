import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static String PROJECT_PATH = new File("").getAbsolutePath();

    public static void main(String[] args) throws IOException, InterruptedException {
        resetFile();
        ProcessBuilder[] processBuilders = new ProcessBuilder[5];
        String[] dividings = {"2","3","4","6","12"};
        for (int i = 0; i < processBuilders.length; i++) {
            processBuilders[i] = createProcessBuilder(String.valueOf(i + 1));
        }

        Process p1 = processBuilders[0].start();
        Process p2 = processBuilders[1].start();
        Process p3 = processBuilders[2].start();

        p1.waitFor();
        p2.waitFor();

        Process p4 = processBuilders[3].start();

        p3.waitFor();
        p4.waitFor();

        Process p5 = processBuilders[4].start();
        p5.waitFor();
    }

    public static ProcessBuilder createProcessBuilder(String processNumber) {
        File log = new File(PROJECT_PATH + "\\files\\log.txt");
        File error = new File(PROJECT_PATH + "\\files\\error.txt");

        String command = "Writer";
        ProcessBuilder processBuilder = new ProcessBuilder("java", "-cp", PROJECT_PATH +
                "\\out\\production\\SP_Tarea2\\", command, log.getAbsolutePath(), processNumber);
        processBuilder.redirectError(error);

        return processBuilder;
    }

    public static void resetFile() {
        File log = new File(PROJECT_PATH + "\\files\\log.txt");
        try {
            FileWriter fileWriter = new FileWriter(log, false);
            fileWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
