import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Writer {
    private File file;
    private String processNumber;

    public Writer(File file, String processNumber) throws InterruptedException {
        this.file = file;
        this.processNumber = processNumber;
        this.write("Se ha iniciado el proceso");
//        this.execute();
    }

    public void write(String message) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
            String text = "Proceso [" + processNumber + "]: " + message;
            bw.write(text);
            bw.write("\n");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void execute() throws InterruptedException {
        TimeUnit.SECONDS.sleep(Long.parseLong("1"));
        write("Proceso [" + processNumber + "]: Se está ejecutando el proceso");
    }

    public static void main(String[] args) throws InterruptedException {
        Writer writer = new Writer(new File(args[0]), args[1]);
        writer.write("Se está ejecutando el proceso");
        writer.write("Se ha terminado el proceso");
    }
}
