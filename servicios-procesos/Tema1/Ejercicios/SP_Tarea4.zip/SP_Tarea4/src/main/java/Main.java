public class Main {
    public static void main(String[] args) throws InterruptedException {
        Coche[] coches = new Coche[10];
        for (int i = 0; i < coches.length; i++) {
            coches[i] = new Coche(i + 1);
        }

        Carrera carrera = new Carrera(coches);
        Thread hilo = new Thread(carrera);
        hilo.start();
    }
}
