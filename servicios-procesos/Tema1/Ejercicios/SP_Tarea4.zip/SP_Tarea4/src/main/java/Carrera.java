import java.util.Random;

public class Carrera implements Runnable {
    private Coche[] coches;
    private static final int CHECKPOINTS = 6;

    public Carrera(Coche[] coches) {
        this.coches = coches;
    }

    public void mostrarTiempos() {
        for (Coche coche : coches) {
            System.out.println("Coche[" + coche.getNumero() + "] acabó en: " + coche.getTiempo() + " ms");
        }
    }

    @Override
    public void run() {
        Random r = new Random();
        for (int i = 0; i < CHECKPOINTS; i++) {
            System.out.println("CHECKPOINT " + (i + 1) + "/" + CHECKPOINTS);
            for (int j = 0; j < coches.length; j++) {
                long tiempo = r.nextLong(1000, 1101);
                /*try {
                    Thread.sleep(tiempo);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }*/
                coches[j].sumarTiempo(tiempo);
                System.out.println("Coche[" + coches[j].getNumero() + "]: llegó en: " + tiempo);
            }
            System.out.println("- - - - - - - - - - -");
        }
        mostrarTiempos();
    }
}
