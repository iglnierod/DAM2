public class Coche {
    private int numero;
    private long tiempo;

    public Coche(int numero) {
        this.numero = numero;
        this.tiempo = 0;
    }

    public int getNumero() {
        return numero;
    }

    public long getTiempo() {
        return tiempo;
    }

    public synchronized void sumarTiempo(long tiempo) {
        this.tiempo += tiempo;
    }
}
