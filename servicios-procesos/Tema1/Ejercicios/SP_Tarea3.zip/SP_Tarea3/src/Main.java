public class Main {
    public static void main(String[] args) {
        Jugador[] jugadores = new Jugador[32];
        for (int i = 0; i < jugadores.length; i++) {
            jugadores[i] = new Jugador("Jugador " + i);
        }

        Partido[] partidos = new Partido[jugadores.length / 2];
        int numJugador = 0;
        for (int i = 0; i < partidos.length; i++) {
            partidos[i] = new Partido(i, new Jugador[]{jugadores[numJugador++], jugadores[numJugador++]});
            Thread partido = new Thread(partidos[i]);
            partido.start();
        }
    }
}
