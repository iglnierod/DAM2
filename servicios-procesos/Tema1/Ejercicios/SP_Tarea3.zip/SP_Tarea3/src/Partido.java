import java.util.Random;

public class Partido implements Runnable {
    private Jugador[] jugadores;
    private int numeroDePartido;

    public Partido(int numeroDePartido, Jugador[] jugadores) {
        this.numeroDePartido = numeroDePartido;
        this.jugadores = jugadores;
//        System.out.println(numeroDePartido + " - " + jugadores[0] + ", " + jugadores[1]);
    }

    @Override
    public void run() {
        System.out.printf("Inicio del partido: %2s\n",numeroDePartido);
        Random r = new Random();
        int random = r.nextInt(0, 2);
        System.out.printf("El ganador del partido [%2s] es: %10s\n",numeroDePartido,jugadores[random]);
        System.out.printf("Fin del partido: %2s\n",numeroDePartido);
    }
}