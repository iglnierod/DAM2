import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Writer {
    private File file;
    private String processNumber;
    private int dividing;

    public Writer(File file, String processNumber, String dividing) throws InterruptedException {
        this.file = file;
        this.processNumber = processNumber;
        this.dividing = Integer.parseInt(dividing);
        calculate();
    }

    private void calculate() {
        for (int i = 1; i < 101; i++) {
            if (i % dividing == 0) {
                write(dividing + " es divisor de " + i);
            }
        }
    }

    private void write(String message) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
            String text = "Proceso [" + processNumber + "]: " + message;
            bw.write(text);
            bw.write("\n");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Writer writer = new Writer(new File(args[0]), args[1], args[2]);
    }
}
