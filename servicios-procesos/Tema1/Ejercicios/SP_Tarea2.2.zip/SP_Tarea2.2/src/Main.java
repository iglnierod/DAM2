import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    static final String PROJECT_PATH = new File("").getAbsolutePath();

    public static void main(String[] args) throws IOException, InterruptedException {
        resetFile();
        ProcessBuilder[] processBuilders = new ProcessBuilder[5];
        String[] dividing = {"2","3","4","6","12"};
        for (int i = 0; i < processBuilders.length; i++) {
            processBuilders[i] = createProcessBuilder(String.valueOf(i + 1), dividing[i]);
        }

        Process div2 = processBuilders[0].start();
        Process div3 = processBuilders[1].start();

        div2.waitFor();
        Process div4 = processBuilders[2].start();

        div3.waitFor();
        Process div6 = processBuilders[3].start();

        div4.waitFor();
        div6.waitFor();
        Process div12 = processBuilders[4].start();
    }

    public static ProcessBuilder createProcessBuilder(String processNumber, String dividing) {
        File log = new File(PROJECT_PATH + "\\files\\log.txt");
        File error = new File(PROJECT_PATH + "\\files\\error.txt");

        String command = "Writer";
        ProcessBuilder processBuilder = new ProcessBuilder("java", "-cp", PROJECT_PATH +
                "\\out\\production\\SP_Tarea2.2\\", command, log.getAbsolutePath(), processNumber, dividing);

        processBuilder.redirectError(error);

        return processBuilder;
    }

    public static void resetFile() {
        File log = new File(PROJECT_PATH + "\\files\\log.txt");
        try {
            FileWriter fileWriter = new FileWriter(log, false);
            fileWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
