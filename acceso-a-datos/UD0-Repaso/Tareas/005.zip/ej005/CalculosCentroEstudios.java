package ej005;

public interface CalculosCentroEstudios {
    int numeroDeAprobados(double[] notas);
    int numeroDeSuspensos(double[] notas);
    double notaMedia(double[] notas);
}
