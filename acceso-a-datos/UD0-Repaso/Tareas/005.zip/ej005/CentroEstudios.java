package ej005;

public interface CentroEstudios extends DatosCentroEstudios, CalculosCentroEstudios {

}
