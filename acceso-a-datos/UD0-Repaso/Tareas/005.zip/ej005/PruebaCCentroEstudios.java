package ej005;

import java.sql.SQLOutput;
import java.util.Random;

public class PruebaCCentroEstudios {
    public static void main(String[] args) {
        CCentroEstudios centro = new CCentroEstudios();

        final int NUM_NOTAS = 20;
        double[] notas = new double[NUM_NOTAS];
        Random r = new Random();
        for (int i = 0; i < NUM_NOTAS; i++) {
            notas[i] = r.nextDouble(0, 11);
        }
        System.out.printf("NOTA MEDIA: %.2f\n",centro.notaMedia(notas));
        System.out.printf("Nº APROBADOS: %d\n",centro.numeroDeAprobados(notas));
        System.out.printf("Nº SUSPENSOS: %d\n",centro.numeroDeSuspensos(notas));

        System.out.println("Nº DE AULAS: "+centro.numeroDeAulas);
        System.out.println("Nº DE PISOS: "+centro.numeroDePisos);
        System.out.println("Nº DE DESPACHOS: " + centro.numeroDeDespachos);

    }
}
