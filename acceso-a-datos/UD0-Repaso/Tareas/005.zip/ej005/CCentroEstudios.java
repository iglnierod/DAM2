package ej005;

public class CCentroEstudios implements CentroEstudios {
    @Override
    public int numeroDeAprobados(double[] notas) {
        int aprobados = 0;
        for(int i = 0; i < notas.length; i++) {
            if(notas[i] >= 5) {
                aprobados++;
            }
        }
        return aprobados;
    }

    @Override
    public int numeroDeSuspensos(double[] notas) {
        int suspensos = 0;
        for(int i = 0; i < notas.length; i++) {
            if(notas[i] < 5) {
                suspensos++;
            }
        }
        return suspensos;
    }

    @Override
    public double notaMedia(double[] notas) {
        double total = 0;
        for(int i = 0; i < notas.length; i++) {
            total += notas[i];
        }
        return total / notas.length;
    }
}
