public class Camion extends Vehiculo{
    private int ejes;

    public Camion(String color, int numRuedas, int cilindrada, int potencia, int ejes) {
        super(color, numRuedas, cilindrada, potencia);
        this.ejes = ejes;
    }

    public int getEjes() {
        return ejes;
    }

    public void setEjes(int ejes) {
        this.ejes = ejes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ejes: " + this.ejes + "\n");
        sb.append("IMPUESTO: " + this.obtenerImpuesto() + "€");
        return super.toString() + sb.toString();
    }

    @Override
    double obtenerImpuesto() {
        return this.getCilindrada() / 30 + this.getPotencia() * 20 + this.getNumRuedas() * 20 + this.getEjes() * 50;
    }
}
