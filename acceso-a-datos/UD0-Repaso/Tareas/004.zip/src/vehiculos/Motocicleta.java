package vehiculos;

public class Motocicleta extends Vehiculo {
    private int numOcupantes;

    public Motocicleta(String color, int numRuedas, int cilindrada, int potencia, int numOcupantes) {
        super(color, numRuedas, cilindrada, potencia);
        this.numOcupantes = numOcupantes;
    }

    public Motocicleta(String color, int numRuedas, int cilindrada, int potencia) {
        super(color, numRuedas, cilindrada, potencia);
    }

    public int getNumOcupantes() {
        return numOcupantes;
    }

    public void setNumOcupantes(int numOcupantes) {
        this.numOcupantes = numOcupantes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nº ocupantes: " + this.numOcupantes + "\n");
        sb.append("IMPUESTO: " + this.obtenerImpuesto() + "€");
        return super.toString() + sb.toString();
    }

    @Override
    double obtenerImpuesto() {
        return this.getCilindrada() / 30 + this.getPotencia() + 30;
    }
}
