import vehiculos.Camion;
import vehiculos.Motocicleta;

public class PruebaVehiculos {
    public static void main(String[] args) {
        Motocicleta moto1 = new Motocicleta("rojo", 2,125,25);
        Motocicleta moto2 = new Motocicleta("verde", 2,125,25,2);
        Camion camion1 = new Camion("azul",4,4000,300,2);
        Camion camion2 = new Camion(null, 24, 15000, 0, 6);

        moto1.setNumOcupantes(2);

        System.out.println(moto2.getCilindrada());

        camion2.setPotencia(800);

        System.out.println("~~~~~~MOTOCICLETA 1:~~~~~~");
        System.out.println(moto1);

        System.out.println("~~~~~~MOTOCICLETA 2:~~~~~~");
        System.out.println(moto2);

        System.out.println("~~~~~~CAMION 1:~~~~~~");
        System.out.println(camion1);

        System.out.println("~~~~~~CAMION 2:~~~~~~");
        System.out.println(camion2);

    }
}