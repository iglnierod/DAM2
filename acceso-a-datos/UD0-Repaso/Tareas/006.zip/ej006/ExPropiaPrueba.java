package ej006;

public class ExPropiaPrueba {

    public static void main(String[] args){
        while(1 == 1) {
            try {
                ExPropiaClase epc = new ExPropiaClase();
                epc.excepcion();
            } catch (ExPropiaClase e){
                System.out.println(e);
            }
        }
    }
}
