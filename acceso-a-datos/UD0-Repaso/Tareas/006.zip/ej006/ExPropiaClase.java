package ej006;

import java.util.Scanner;

public class ExPropiaClase extends Exception {
    public ExPropiaClase() throws ExPropiaClase{
        super("Excepción de ExPropiaClase");
    }
    private final int COD_ERROR = 0;

    Scanner sc = new Scanner(System.in);

    void excepcion() throws ExPropiaClase {
        System.out.print("Introduce un número: ");
        int num = sc.nextInt();
        sc.nextLine();
        if(num == COD_ERROR)
            throw new ExPropiaClase();
    }
}
