public class Vehiculo {
    public Vehiculo(String color, int numRuedas, int cilindrada, int potencia) {
        this.color = color;
        this.numRuedas = numRuedas;
        this.cilindrada = cilindrada;
        this.potencia = potencia;
    }

    private String color;
    private int numRuedas;
    private int cilindrada;
    private int potencia;

    public String getColor() {
        return color;
    }

    public int getNumRuedas() {
        return numRuedas;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setNumRuedas(int numRuedas) {
        this.numRuedas = numRuedas;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Color: " + this.color + "\n");
        sb.append("Nº ruedas: " + this.numRuedas + "\n");
        sb.append("Cilindrada: " + this.cilindrada + "\n");
        sb.append("Potencia: " + this.potencia + "\n");
        return sb.toString();
    }
}
