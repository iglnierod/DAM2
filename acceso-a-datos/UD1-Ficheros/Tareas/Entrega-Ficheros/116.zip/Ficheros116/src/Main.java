import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Introduce una vocal: ");
            char vocal = sc.next().charAt(0);
            System.out.println(vocal);

            try (BufferedReader br = new BufferedReader(new FileReader("refranes.txt"));
                 BufferedWriter bw = new BufferedWriter(new FileWriter("refranes_CON_" + vocal + ".txt"))) {

                String linea;
                while ((linea = br.readLine()) != null) {
                    linea = cambiarVocales(linea, vocal);
                    System.out.println(linea);
                    bw.write(linea);
                    bw.newLine();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static String cambiarVocales(String input, char vowel) {
        char lowerVowel = Character.toLowerCase(vowel);
        String vocales = "[aeiou]";
        String vocalesMayusculas = String.valueOf(Character.toUpperCase(vowel));
        return input.replaceAll(vocales, String.valueOf(lowerVowel)).replaceAll(vocales.toUpperCase(), vocalesMayusculas);
    }
}

