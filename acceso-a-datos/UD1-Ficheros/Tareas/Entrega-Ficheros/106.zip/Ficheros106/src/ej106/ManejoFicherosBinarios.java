package ej106;

import java.io.File;

public class ManejoFicherosBinarios {
    public static void main(String[] args) {
        String rutaOrigen = "origen.bin";
        String rutaDestino = "destino.bin";
        FicheroBinario fb = new FicheroBinario(new File(rutaOrigen));
        fb.escribir("ESTE ES EL TEXTO DE ORIGEN.");
        fb.leer();

        FicheroBinario destino = new FicheroBinario(new File(rutaDestino));
        fb.copiar(destino);
    }
}
