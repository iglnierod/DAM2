import java.io.*;
import java.util.Scanner;
import java.util.zip.*;

public class DirectorioAZip {
    Scanner sc;
    File ruta;
    File zip;

    public DirectorioAZip() {
        this.sc = new Scanner(System.in);
        this.ruta = null;
        this.zip = null;
        pedirRuta();
    }

    public void pedirRuta() {
        System.out.print("Introduce la ruta de una carpeta para comprimirla: ");
        this.ruta = new File(sc.nextLine());
        if (this.ruta.isFile() || !this.ruta.exists()) {
            System.out.println("ERROR: La ruta introducida no es válida.");
            pedirRuta();
        }
        System.out.println("Se ha añadido la ruta correctamente.");
        crearZIP();
    }

    public void crearZIP() {
        String rutaParent = this.ruta.getParent();
        String zipName = this.ruta.getName() + ".zip";
        this.zip = new File(rutaParent, zipName);
        try {
            this.zip.createNewFile();
            FileOutputStream fos = new FileOutputStream(zip);
            ZipOutputStream zipOut = new ZipOutputStream(fos);
            System.out.println("~~~~~~~~ Añadiendo archivos... ~~~~~~~~");
            for (File f : ruta.listFiles()) {
                agregarAZip(f, f.getName(), zipOut);
                System.out.println("Se ha añadido al archivo '" + zip.getName() + "' el " + (f.isDirectory() ? "directorio" : "archivo") +  ": " + f.getName());
            }
            zipOut.close();
            fos.close();
            System.out.println("Completada la compresión del directorio " + ruta.getName() + " a .zip");
            System.out.println("La ruta del nuevo archivo comprimido es: " + zip.getAbsolutePath());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    public void agregarAZip(File fileToZip, String fileName, ZipOutputStream zipOut) {
        try {
            if (fileToZip.isDirectory()) {
                String folderName = fileName.endsWith("/") ? fileName : (fileName + "/");
                zipOut.putNextEntry(new ZipEntry(folderName));
                zipOut.closeEntry();

                File[] children = fileToZip.listFiles();
                for (File childFile : children) {
                    agregarAZip(childFile, fileName + "/" + childFile.getName(), zipOut);
                }
                return;
            }

            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileName);
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int lenght;
            while ((lenght = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, lenght);
            }
            fis.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
