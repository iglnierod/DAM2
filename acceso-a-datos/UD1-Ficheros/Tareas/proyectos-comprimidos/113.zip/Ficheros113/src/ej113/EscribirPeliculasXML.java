package ej113;

import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class EscribirPeliculasXML {
    public static String pathXMLFiles = new File("").getAbsolutePath() + "\\XML\\";

    public static void main(String[] args) {
        File sourceFile = new File(pathXMLFiles + "peliculas.xml");

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(sourceFile);
            transform(document);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public static void transform(Document document) {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();

            DOMSource source = new DOMSource(document);
            File destinationFile = new File(pathXMLFiles + "copiaPeliculas.xml");
            StreamResult result = new StreamResult(destinationFile);

            transformer.transform(source, result);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }
}
