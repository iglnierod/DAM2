import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import java.io.*;

public class XmlToJson {
    static final String PROJECT_PATH = new File("").getAbsolutePath();

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new FileReader(new File(PROJECT_PATH, "\\files\\bookstore.xml")));
             BufferedWriter writer = new BufferedWriter(new FileWriter(new File(PROJECT_PATH, "\\files\\bookstore.json")))) {

            StringBuilder sb = new StringBuilder();
            String line = null;

            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();

            String xmlEntrada = sb.toString();

            JSONObject json = XML.toJSONObject(xmlEntrada);
            String jsonString = json.toString(4);
            writer.write(jsonString);
            System.out.println("Se ha convertido el archivo correctamente.");
            System.out.println(jsonString);
        } catch (IOException | JSONException e) {
            throw new RuntimeException(e);
        }
    }
}