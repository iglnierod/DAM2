import java.io.Serializable;

public class Estudiante implements Serializable {
    private String nombre;
    private int id;
    private int edad;
    private double notaMedia;

    public Estudiante(String nombre, int id, int edad, double notaMedia) {
        this.nombre = nombre;
        this.id = id;
        this.edad = edad;
        this.notaMedia = notaMedia;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "nombre='" + nombre + '\'' +
                ", id=" + id +
                ", edad=" + edad +
                ", notaMedia=" + notaMedia +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public int getEdad() {
        return edad;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }
}
