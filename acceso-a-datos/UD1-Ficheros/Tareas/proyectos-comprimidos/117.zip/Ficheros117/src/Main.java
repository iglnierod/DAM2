import java.sql.SQLOutput;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ManejadorEstudiantes manejador = new ManejadorEstudiantes();
        int opcion = 0;
        String separador = "--------------------------------";
        while (opcion != 4) {
            System.out.println(separador);
            System.out.println("1.Agregar un nuevo estudiante.");
            System.out.println("2.Mostrar la información de todos los estudiantes almacenados.");
            System.out.println("3.Guardar la información de los estudiantes en un archivo mediante la serialización de objetos.");
            System.out.println("4.Salir del programa");
            opcion = sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                case 1:
                    System.out.println(separador);
                    System.out.println("1.Agregar un nuevo estudiante:");
                    String nombre = null;
                    int id = 0;
                    int edad = 0;
                    double notaMedia = 0;
                    boolean estudianteIntroducido = false;
                    while (!estudianteIntroducido) {
                        try {
                            System.out.print("Nombre: ");
                            nombre = sc.nextLine();
                            System.out.print("id: ");
                            id = sc.nextInt();
                            System.out.print("Edad: ");
                            edad = sc.nextInt();
                            System.out.print("Nota media: ");
                            notaMedia = sc.nextDouble();
                            estudianteIntroducido = true;
                        } catch (InputMismatchException e) {
                            sc.nextLine();
                            System.out.println(separador);
                            System.out.println("ERROR: No se han introducido correctamente los datos del estudiante.");
                            System.out.println(separador);
                        }
                    }
                    Estudiante estudiante = new Estudiante(nombre, id, edad, notaMedia);
                    manejador.addEstudiante(estudiante);
                    break;
                case 2:
                    System.out.println(separador);
                    System.out.println("2.Mostrar la información de todos los estudiantes almacenados.");
                    manejador.showEstudiantes();
                    break;
                case 3:
                    System.out.println(separador);
                    System.out.println("3.Guardar la información de los estudiantes en un archivo mediante la serialización de objetos.");
                    manejador.serializar();
                    break;
                case 4:
                    break;
                default:
                    System.out.println(separador);
                    System.out.println("ERROR: El número introducido no es válido");
            }
        }
    }
}
