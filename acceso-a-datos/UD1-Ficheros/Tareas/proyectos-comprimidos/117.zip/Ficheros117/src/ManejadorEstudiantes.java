import java.io.*;
import java.util.ArrayList;

public class ManejadorEstudiantes {
    private ArrayList<Estudiante> estudiantes;
    private File archivoEstudiantes;

    public ManejadorEstudiantes() {
        this.estudiantes = new ArrayList<>();
        archivoEstudiantes = new File("estudiantes.dat");
        checkEstudiantesSerializados();
    }

    public void addEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public void showEstudiantes() {
        for (Estudiante estudiante : estudiantes) {
            System.out.println(estudiante);
        }
    }

    public void serializar() {
        try (FileOutputStream fos = new FileOutputStream(archivoEstudiantes);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            if (estudiantes.size() == 0) {
                System.out.println("ERROR: No hay estudiantes.");
                return;
            }
            oos.writeObject(estudiantes);
            System.out.println("Se ha guardado los estudiantes en el archivo: " + archivoEstudiantes);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkEstudiantesSerializados() {
        if (archivoEstudiantes.exists()) {
            System.out.println("Estudiantes serilizados y guardados anteriormente: ");
            try (FileInputStream fis = new FileInputStream(archivoEstudiantes);
                 ObjectInputStream ois = new ObjectInputStream(fis)) {
                estudiantes = (ArrayList<Estudiante>) ois.readObject();
                showEstudiantes();
            } catch (IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
