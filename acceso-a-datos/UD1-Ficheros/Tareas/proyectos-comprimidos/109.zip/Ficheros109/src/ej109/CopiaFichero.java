package ej109;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class CopiaFichero {
    public static void main(String[] args) {
        String rutaDir = new File("").getAbsolutePath() + "\\dir\\";
        Path origen = Paths.get(rutaDir + "origen.txt");
        Path destino = Paths.get(rutaDir + "destino.txt");
        try {
            FileInputStream in = new FileInputStream(origen.toFile());
            Files.copy(in, destino, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Se ha copiado el texto del archivo origen.txt a destino.txt");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
