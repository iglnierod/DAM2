import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ManejoProductos manejador = new ManejoProductos();
        ArrayList<Producto> productos;
        productos = manejador.crearProductos();
        manejador.almacenarProductos(productos);
        manejador.leerProductos();
    }
}
