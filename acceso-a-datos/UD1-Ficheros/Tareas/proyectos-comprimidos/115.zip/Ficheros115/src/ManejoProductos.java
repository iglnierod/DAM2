import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ManejoProductos {

    private final File bin = new File("productos.bin");

    public ArrayList<Producto> crearProductos() {
        int[] identificadores = {123, 456, 789, 235, 567};
        String[] descripciones = {"cafe", "leche", "arroz", "sal", "coco"};
        double[] precios = {1.22, 1.05, 1, 1.25, 3.2};

        ArrayList<Producto> productos = new ArrayList<>();

        for (int i = 0; i < identificadores.length; i++) {
            int identificador = identificadores[i];
            String descripcion = descripciones[i];
            float precio = (float) precios[i];
            productos.add(new Producto(identificador, descripcion, precio));
        }

        return productos;
    }

    public void almacenarProductos(ArrayList<Producto> productos) {
        try (FileOutputStream fos = new FileOutputStream(bin, true)) {
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Producto producto : productos) {
                oos.writeObject(producto);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void leerProductos() {

        try (FileInputStream fis = new FileInputStream(bin)) {
            ObjectInputStream ois = new ObjectInputStream(fis);
            Producto producto;

            while (true) {
                try {
                    producto = (Producto) ois.readObject();
                    System.out.println(producto);
                } catch (Exception e) {
                    System.out.println("Fin del archivo.");
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
