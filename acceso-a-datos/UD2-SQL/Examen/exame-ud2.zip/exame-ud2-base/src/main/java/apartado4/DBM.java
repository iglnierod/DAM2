package apartado4;

public enum DBM {
    MYSQL,SQLITE
}
