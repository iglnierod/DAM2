package ej203;

public enum Estado {
    PENDIENTE, EN_PROCESO, COMPLETADA
}
