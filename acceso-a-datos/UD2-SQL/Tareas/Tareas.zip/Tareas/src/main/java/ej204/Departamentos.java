package ej204;

import java.util.ArrayList;

public class Departamentos {
//    private ArrayList<Departamento> deps;
//
//    public ArrayList<Departamento> getAll() {
//        // consulta
//        return deps;
//    }
//
//    public ArrayList<Departamento> getWhere() {
//
//    }
}
