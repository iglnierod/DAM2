package ej205;

public enum DBMS {
    MySQL, SQLite
}
