package ej204;

public class Departamento {
    private int numdep;
    private String nombre;
    private String localidad;
    private int numjefe;

    public Departamento() {

    }

    public int getNumdep() {
        return numdep;
    }

    public void setNumdep(int numdep) {
        this.numdep = numdep;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public int getNumjefe() {
        return numjefe;
    }

    public void setNumjefe(int numjefe) {
        this.numjefe = numjefe;
    }
}
