package com.example.dependencias.login

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class loginApp: Application() {
}