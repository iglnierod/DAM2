package com.example.todoapp.addtask.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks_table")
data class TaskEntity(
    @PrimaryKey
    val id: Int ,
    var task: String,
    var selected: Boolean = false
)