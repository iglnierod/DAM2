package com.example.todoapp.addtask.ui.model

data class TaskModel (val id:Int = System.currentTimeMillis().hashCode() , var task: String, var selected: Boolean = false)
