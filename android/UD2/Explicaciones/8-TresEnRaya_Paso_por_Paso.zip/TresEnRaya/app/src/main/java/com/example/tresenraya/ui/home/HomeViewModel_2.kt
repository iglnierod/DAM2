package com.example.tresenraya.ui.home

import androidx.lifecycle.ViewModel
import com.example.tresenraya.data.network.FirebaseService
import com.example.tresenraya.data.network.model.GameData
import com.example.tresenraya.data.network.model.PlayerData
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Calendar
import javax.inject.Inject


@HiltViewModel
class HomeViewModel_2 @Inject constructor() : ViewModel() {

    fun onCreateGame_2() {
        //PENDIENTE DE DESARROLLO
    }

    fun onJoinGame_2(id: String) {
        //PENDIENTE DE DESARROLLO
    }
}