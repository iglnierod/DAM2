package com.example.tresenraya.ui.theme

import androidx.compose.ui.graphics.Color

val Purple81 = Color(0xFFD0BCFF)
val PurpleGrey81 = Color(0xFFCCC2DC)
val Pink81 = Color(0xFFEFB8C8)

val Purple41 = Color(0xFF6650a4)
val PurpleGrey41 = Color(0xFF625b71)
val Pink41 = Color(0xFF7D5260)


/*15.2- Vamos a definir unos colores nuevos con flow firebase y nos vamos al HomeScreen de nuevo*/
val BackgroundA = Color(0xFF27313E)
val Orange1A = Color(0xFFF1701F)
val Orange2A = Color(0xFFFDC33F)
val AccentA = Color(0xFFFFFFFF)
val BlueLinkA = Color(0xFF00B3FF)