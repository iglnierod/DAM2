package com.example.tresenraya.ui.game

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class GameViewModel_3 @Inject constructor(): ViewModel(){
    /*3.6 Creamos el viewmodel y se lo pasamos a la screen para que quede preparado para empezar a
    trabajar con datos */
}