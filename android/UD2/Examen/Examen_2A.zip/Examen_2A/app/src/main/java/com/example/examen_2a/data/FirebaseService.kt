package com.example.examen_2a.data

import com.example.examen_2a.ui.model.ContactoModel
import com.google.firebase.database.DatabaseReference
import javax.inject.Inject

class FirebaseService @Inject constructor(private val reference: DatabaseReference) {

    companion object {
        const val PATH = "contactos"
    }

    fun addContacto(pedido: ContactoModel) {
        val contactoRef = reference.child(PATH).push()
        val codUsuario = contactoRef.key
        val newPedido = pedido.copy(codUsuario = codUsuario.orEmpty())
        contactoRef.setValue(newPedido)
    }

    /**********************************************************************************************/
    /*Ejercicio 2: Crear una función obtenerContactos que obtenga los datos que guardamos en realtime database
    (4 puntos)*/
    fun obtenerContactos() {

    }

    /**********************************************************************************************/
    /*Ejercicio 3: Crea una función que permita eliminar el contacto (3 puntos)*/
    fun deleteContacto() {

    }

}

