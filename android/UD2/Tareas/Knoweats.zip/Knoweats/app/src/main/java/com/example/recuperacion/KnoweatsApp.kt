package com.example.recuperacion

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class KnoweatsApp: Application()