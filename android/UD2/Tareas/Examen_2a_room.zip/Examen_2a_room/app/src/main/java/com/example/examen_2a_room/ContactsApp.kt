package com.example.examen_2a_room

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ContactsApp : Application()