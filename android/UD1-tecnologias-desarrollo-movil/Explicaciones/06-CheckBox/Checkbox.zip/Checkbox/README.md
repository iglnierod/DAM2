### Temas tratados:
- Switch
- CheckBox
- CheckBox con State Hoising
- TriStateCheckBox

[Documentación switch](https://developer.android.com/jetpack/compose/components/switch?hl=es-419)
[Documentación checkBox](https://developer.android.com/reference/kotlin/androidx/compose/material/package-summary#Checkbox(kotlin.Boolean,kotlin.Function1,androidx.compose.ui.Modifier,kotlin.Boolean,androidx.compose.foundation.interaction.MutableInteractionSource,androidx.compose.material.CheckboxColors))
[Documentación State Hoising](https://developer.android.com/jetpack/compose/state-hoisting?hl=es-419)
