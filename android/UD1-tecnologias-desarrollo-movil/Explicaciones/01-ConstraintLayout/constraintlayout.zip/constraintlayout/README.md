### Temas tratados:
- Utilización de la librería
- Funciones básicas: createRefs(), constraintAs(), linkTo()
- Posicionamiento: parent.top, parent.bottom, parent.start, parent.end
- Guías, Barreras y Cadenas

[Documentación oficial ConstraintLayout](https://developer.android.com/jetpack/compose/layouts/constraintlayout?hl=es-419)
