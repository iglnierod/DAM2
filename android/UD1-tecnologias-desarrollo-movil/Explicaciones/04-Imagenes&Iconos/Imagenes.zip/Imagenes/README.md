### Temas:

- Imágenes en local o internet
- Librerías Iconos
- Formateo de imágenes


[Documentación oficial Imágenes](https://developer.android.com/jetpack/compose/graphics/images?hl=es-419)
[Documentación oficial Iconos](https://developer.android.com/jetpack/compose/graphics/images/material?hl=es-419)
