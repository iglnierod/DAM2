### Temas:

- Progress Bar Circular
- Progress Bar Linear

[Documentación oficial ProgressBar](https://developer.android.com/jetpack/compose/components/progress?hl=es-419)