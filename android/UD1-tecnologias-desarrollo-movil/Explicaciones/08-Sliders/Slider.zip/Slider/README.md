### Temas tratados:
- Sliders

[Documentación](https://developer.android.com/reference/kotlin/androidx/compose/material/package-summary#slider)