### Temas tratados:
- Dialog
- AlertDialog

[Documentación](https://developer.android.com/jetpack/compose/components/dialog?hl=es-419)
[Ejemplos MaterialDesign 2](https://m2.material.io/components/dialogs#usage)