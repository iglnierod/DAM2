package com.example.dialogs.ui.theme

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.dialogs.R

@Composable
fun MyTitulo(text: String) {
    Icon(
        painter = painterResource(id = R.drawable.baseline_brightness_6_white_36),
        contentDescription = null,
        tint = Color.White,
        modifier = Modifier
            .size(size = 24.dp)
    )

    Text(
        text = text,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        modifier = Modifier.padding(8.dp),
        color = Color(0xFF32A7D3)
    )

}

@Composable
fun MyAccountItem(email: String, @DrawableRes drawable: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = drawable),
            contentDescription = "Avatar cuenta de correo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .padding(15.dp)
                .size(40.dp)
                .clip(CircleShape)
        )

        Text(text = email, fontSize = 14.sp)
    }

}


/********************************** DIALOGO CON RADIOBUTTONS **************************************/
/**************************************************************************************************/

@Composable
fun MyConfirmationDialog(show: Boolean, onDismiss: () -> Unit) {
    if (show) {
        Dialog(onDismissRequest = { /*TODO*/ }) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MyTitulo(text = "Brightness")
                }
                Divider(Modifier.fillMaxWidth(), color = Color(0xFF2FC3FA))
                var status by remember { mutableStateOf("") }
                MyBrightnessCheckbox("Automatic brightness", false)
                Divider(Modifier.fillMaxWidth(), color = Color.Gray)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.15.dp, Color.Gray, RectangleShape),
                    Arrangement.SpaceBetween,

                    ) {
                    TextButton(
                        onClick = { /*TODO*/ },
                        modifier = Modifier
                            .border(1.dp, Color.Gray, RectangleShape)
                    ) {
                        Text(
                            text = "ACEPTAR",
                            color = Color.White,
                            modifier = Modifier
                                .padding(35.dp, 10.dp)
                        )
                    }
                    TextButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .border(1.dp, Color.Gray, RectangleShape)
                    ) {
                        Text(
                            text = "CANCELAR",
                            color = Color.White,
                            modifier = Modifier
                                .padding(35.dp, 10.dp)

                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MyBrightnessCheckbox(text: String, checked: Boolean) {
    var newChecked by remember { mutableStateOf(checked) }
    var sliderValue by remember { mutableStateOf(0.5f) }

    Column() {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(2.dp, 0.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                enabled = true,
                checked = checked,
                onCheckedChange = { newChecked = it },
                colors = CheckboxDefaults.colors(checkedColor = Color.Blue)
            )
            Text(
                text = text, color = Color.White
            )
        }

        Slider(
            value = sliderValue,
            valueRange = 0f..1f,
            onValueChange = { newValue ->
                sliderValue = newValue
            },
            modifier = Modifier.padding(10.dp, 20.dp),
            colors = SliderDefaults.colors(activeTrackColor = Color.Cyan)
        )
    }
}

